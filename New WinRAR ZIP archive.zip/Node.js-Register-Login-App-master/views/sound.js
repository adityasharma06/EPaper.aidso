document.addEventListener('keydown', function(e) {
    document.getElementById('audio').playbackRate = 4;
document.getElementById('audio').play();
});