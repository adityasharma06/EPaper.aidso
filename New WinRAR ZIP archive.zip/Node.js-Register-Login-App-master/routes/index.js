const express = require('express');
const router = express.Router();
const User = require('../models/user');
mailer = require('nodemailer');
const bodyParser = require("body-parser")
const fs = require('fs');
const path = require('path');
const app = express();
const xlsx = require('xlsx');
const {MongoClient} = require('mongodb')
// const multer = require('multer');
const upload = require ('express-fileupload')
router.use(upload());
router.use(bodyParser.urlencoded({
    extended:true
}));
const url = 'mongodb://127.0.0.1:27017';
const client = new MongoClient(url);
const dbName = 'paperdata';
var finaldata;
var dataview = {}
async function main() {
// Use connect method to connect to the server
let result = await client.connect();
// console.log('Connected successfully to server');
let db = result.db(dbName);
const collection = db.collection('paper');
let response =  await collection.find({}).toArray()
// the following code examples can be pasted here...
// console.log(response)
for(i=0; i<response.length; i++){

if(response[i].code!=undefined && response[i].chapters !=undefined )
{
 a = response[i].code
 b = response[i].chapters 
 dataview[a] = b;    
}
}
return dataview;
}
main()
.then()
.catch(console.error)
.finally(() => client.close());
smtpProtocol = mailer.createTransport({
    service: "Gmail",
    auth: {
        user: "adityasharma3819@gmail.com",
        pass: 'dhdtjuwmcetschgo'
    }
});
router.get('/', (req, res, next) => {
	return res.render('index.ejs');
});
router.post('/', (req, res, next) => {
	let personInfo = req.body;
	if (!personInfo.email || !personInfo.username || !personInfo.tel) {
		res.send();
	} else {
	User.findOne({ email: personInfo.email }, (err, data) => {
				if (!data) {
					let c;					
					User.findOne({}, (err, data) => {
						if (data) {
							c = data.unique_id + 1;
						} else {
							c = 1;
						}
						let name = personInfo.email
						let username = "epaper-"+ personInfo.email + "-"+ Math.floor(Math.random() * 900) + 1000;
						var charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+~`|}{[]:;?><,./-=";
						var password =""
						for (var i = 0, n = charset.length; i < 8; ++i) {
						  password += charset.charAt(Math.floor(Math.random() * n));
						}
						console.log( "password : " , password ,"\n","username " ,  username )
						let newPerson = new User({
							unique_id: c,
							email: personInfo.email,
							username: username,
							password: password 
						});
						newPerson.save((err, Person) => {
							if (err)
							console.log(err);
							else
							console.log('Success');
						});
					}).sort({ _id: -1 }).limit(1);
					res.send({ "Success": "You are regestered,Your Register Login and password send to email" });
				} else {
					res.send({ "Success": "Email is already used." });
				}
			});
		}
	});
    router.get('/addedit', (req, res, next) => {
        User.findOne({ unique_id: req.session.userId }, (err, data) => {
            if (!data) {
                res.redirect('/');
            } else {
                return res.render('addedit.ejs');
            }
        });
    });
    
    router.get('/edit', (req, res, next) => {
        User.findOne({ unique_id: req.session.userId }, (err, data) => {
            if (!data) {
                res.redirect('/');
            } else {
                return res.render('edit.ejs' , { files: dataview } );
            }
        });
	});
    router.post('/edit', (req, res, next) => {
        console.log(req.body)
        const subject  = req.body.subject
        const chapters = req.body.chapters
        const question = req.body.addque
        const level    = req.body.Level
        const marks    = req.body.marks
        const workbook = xlsx.readFile(__dirname+'\\public\\paper\\'+subject+'.xlsx');
        // Get the sheet you want to add data to
        const sheetName =  chapters;
        const worksheet = workbook.Sheets[sheetName];
        
        // Create an array of data to add
        const newData = [
            {question: question,
             marks: marks,
             category: level
            },
        ];
    // Convert the data to a worksheet and append it to the existing sheet
    const newWorksheet = xlsx.utils.json_to_sheet(newData);
    xlsx.utils.sheet_add_json(worksheet, newData, {skipHeader: true, origin: -1});
    // Write the updated workbook back to the file
    xlsx.writeFile(workbook, __dirname+'\\public\\paper\\'+subject+'.xlsx');
    // Send a response to the client
    res.send("Data added successfully");     
    });
    
    router.get('/add', (req, res, next) => {
        User.findOne({ unique_id: req.session.userId }, (err, data) => {
            if (!data) {
                res.redirect('/');
            } else {
                return res.render('add.ejs' , { files: dataview } );
            }
        });
	});
    router.post("/add", function(req, res){
        console.log(req.body)
        if(req.files){
            var file = req.files.file
            var file_name = file.name
            console.log(file_name);
            file.mv( __dirname+'\\public\\paper\\'+file_name,function(err){
                if (err){
                    console.log(err)
                }
                else(console.log("folder uploded"))
            })
        }
        // connect to MongoDB database
        const code = req.body.subject
        const chapters = req.body.chapters
        // subject: '22025', chapters: '4' 
        const url = 'mongodb://127.0.0.1:27017';
        const client = new MongoClient(url);
         const dbName = 'paperdata';
        async  function main() {
            // Use connect method to connect to the server
            let result = await client.connect();
            // console.log('Connected successfully to server');
            let db = result.db(dbName);
            const collection = db.collection('paper');
            // console.log(collection)
            return collection
         }
            const insert = async ()=> {
                const db = await main()
                // console.log(db)
                const result = await db.insertOne({
                    code:code,
                    chapters:chapters
                }) 
                console.log(result)
                return true
            }
            insert()      
        if(insert){res.send({ "Success": "Success!" });
					
        } else {
            res.send({ "Success": "Wrong password!" });
        }
    })

    router.get('/tutorial', (req, res, next)  => {
        return res.render('tutorial.ejs' , { files: dataview });
    });
var marks = null
var chapters1 = null
var subject = null
    
router.post('/tutorial', (req, res, next) => {
        const inputText = req.body.inputText;
        console.log(inputText);
        marks = req.body.Marks
        chapters1 =  req.body.chapters
         subject = req.body.subject;
        res.redirect('/tutorial1');
      });
      router.get('/tutorial1', (req, res, next)  => {
        User.findOne({ unique_id: req.session.userId }, (err, data) => {
            if (!data) {
                res.redirect('/');
            } else {
                async function senddat(){         
                    console.log(chapters1, subject)
                    async function gendata(){
                        let data = [] 
                        var chars = chapters1
                        let file_name = __dirname+'\\public\\paper\\'+subject+'.xlsx'
                        let workbook = xlsx.readFile(file_name);
                        if(chars.length < 8){
                            for(let i=0; i<chars.length; i++){
                                let sheetName = chars[i];
                                let sheet = workbook.Sheets[sheetName]; 
                                console.log(sheetName)
                                let jsonData = xlsx.utils.sheet_to_json(sheet);
                                for( var j in jsonData){    
                                    data.push(jsonData[j])
                                }
                                //   console.log("data",data)
                                
                            }
                        }
                        else{
                            let sheetName = chars;
                            // console.log(chars.length , chars)
                            let sheet = workbook.Sheets[sheetName];
                            let jsonData = xlsx.utils.sheet_to_json(sheet);
                            for( var j in jsonData){    
                                data.push(jsonData[j])
                            } 
                            console.log( sheetName )
                        }
                        return data;  
                    }
                    let R2 = 0
                    // console.log(R4,A4,U4)
                    let data1 = await gendata();
                    console.log(data1)
                    let ROBJ = null
                    ROBJ =data1.filter(object => object.category == "R");
                    let AOBJ =  null
                    AOBJ =  data1.filter(object => object.category == "A");
                    let UOBJ = null
                    UOBJ =  data1.filter(object => object.category == "U");
                    // console.log(UOBJ) 
                    let curma = 0;
                    let question1 = []
                    let question2 = []
                    let question3 = []
                    let question4 = []
                    let question5 = []
                    let question6 = []
                    let arrayquestion = []
                    var newdata = new Array()
                    // console.log('XLSX files (global):', dataview);
                    console.log(marks)
                    if( marks ==20 ){
                        curma = 0 
                        R2 = 5
                        while (curma < 10 ){
                            console.log(R2,curma)
                            if( curma== 0 && curma < (R2*2)){
                                for(i=1; i <= R2; i++){
                                    let J = Math.floor(Math.random() * ROBJ.length);
                                    if(ROBJ != undefined && curma <= R2*2 && ROBJ[J].marks==2){
                                 let temp =  " " +  ROBJ[J].question + " "+'<br>' 
                                 if(!arrayquestion.includes(ROBJ[J].question)) {
                                     question1.push( question1.length+1 + ")  " + temp)
                                     arrayquestion.push(ROBJ[J].question )
                                     curma +=2 
                                    }else i-- 
                                } else i--
                            }
                        }  
                    }
                    // 4marks question         
                    //   console.log('this is final' , curma)   
                    if(curma == 10){
                        curma = 0 
                        if(curma == 0 && !newdata.includes("<h2>Q.2 Attempt any THREE of the following: </h2> <br> ")){
                            //   console.log("nahi hua print ")
                            newdata.push("<h2>Q.2 Attempt any THREE of the following: </h2> <br> ")
                        }
                        while (curma < 16 ){
                            if(newdata.length==1 && newdata.length<2 ){
                                for(var i=1; i <= 2; i++){
                                    // console.log(curma); 
                                    let J = Math.floor(Math.random() * ROBJ.length);
                                    if(ROBJ != undefined &&  ROBJ[J].marks==4){  
                                        let temp = newdata.length+") " + " " +  ROBJ[J].question + " "+'<br>' 
                                            if(!arrayquestion.includes(ROBJ[J].question  )) { 
                                                newdata.push( temp)
                                                curma +=4
                                                arrayquestion.push(ROBJ[J].question )
                                                // console.log("0k")
                                            }
                                        } else i--
                                    }
                                }
                                if( newdata.length==2 && newdata.length<3)
                                {
                                    for(i=1; i <= 2; i++){
                                        let J = Math.floor(Math.random() * AOBJ.length);
                                        if(AOBJ != undefined  && AOBJ[J].marks==4){
                                            let temp =  newdata.length+")  " + " " +  AOBJ[J].question + " "+'<br>' 
                                            if(!arrayquestion.includes(AOBJ[J].question)) { 
                                                newdata.push( temp)
                                                arrayquestion.push(AOBJ[J].question )
                                                curma +=4
                                                // console.log("0k")
                                                // console.log(curma)
                                            }
                                        } else i--
                                    }
                                }
                                else if(  newdata.length>= 3 && newdata.length <=4){
                                    for(i=0; i < 2; i++)
                                    {
                                        let J = Math.floor(Math.random() * UOBJ.length);
                        if(UOBJ != undefined  && UOBJ[J].marks==4 && curma<16){
                            let temp =  newdata.length+")  " +" " +  UOBJ[J].question + '<br>' 
                            if(!arrayquestion.includes(UOBJ[J].question)) { 
                                newdata.push( temp)
                                arrayquestion.push(UOBJ[J].question )
                                curma +=4
                            }
                        } 
                        
                    }
                    //   console.log(newdata.length)  
                    
                }
            }
        }
        res.send(`
        <div class="header" style='display:flex flex-row '>
        <h1 align="right" style="margin-right:2vw">`+ subject + `</h1>
        <div style="display:flex;">
        <h3 align="right" style="margin-right:70vw"> 1 Hours /marks 20 </h3>
        <h3 style="font-weight:bold">  Seat number - _ _ _ _ _ _ _ </h3> 
        </div>
        <hr>
        <h5>Instructions: </h5>
        (1) All questions are compulsory. <br>
        (2) Illustrate your answers with neat sketches whenever necessary. <br>
        (3) Figure to the right indicate full marks. <br>
        (4) Assume suitable fata if necessary. <br>
        (5) Preferably, write the answers in sequential order. <br>
        <hr>
        </div>` +
        ` <div style='margin-left:20px'>
        <h2> Q1. Attempt any four of the following: (10 marks) </h2> <main align='left '>` + 
        question1.join(' ') +newdata.join(' ') +
        `</main> 
        <input id="printpagebutton" type="button" value="Print Question paper" style=' margin-top: 25px;' onclick="printpage()"/>
        <script>
        function printpage() {
            //Get the print button and put it into a variable
            var printButton = document.getElementById("printpagebutton");
            //Set the print button visibility to 'hidden' 
            printButton.style.visibility = 'hidden';
            //Print the page content
            window.print()
            printButton.style.visibility = 'visible';
        }
        </script> `
        )}
        else if (marks==70)
        {
            let answers = `<textarea name="inputText"></textarea>  <input type="file" name="file" required class="form-control" > <br>`
            curma = 0 
            R2 = 7
            while (curma < 14 ){ 
                var tempque = []
                if( curma== 0 && curma < (R2*2)){
                    var RQ2 = ROBJ.filter(object => object.marks == 2);
                    if (RQ2.length < 8) {
                        question1.push("not sufficent question in db <br/>")
                        question1.push("not sufficent question in db <br/> ")
                        question1.push("not sufficent question in db <br/> ")
                        question1.push("not sufficent question in db <br/> ")
                        question1.push("not sufficent question in db <br/> ")
                        question1.push("not sufficent question in db <br/> ")
                        question1.push("not sufficent question in db <br/> ")  
                        curma = 14
                        console.log("ok")
                    }
                    else{
                        for(i=1; i <= R2; i++){
                            let J = Math.floor(Math.random() * ROBJ.length);
                            if(ROBJ != undefined && curma <= R2*2 && ROBJ[J].marks==2 && ROBJ[J].question!=undefined){
                                let temp =  " " +  ROBJ[J].question + " "+'<br>' + answers
                                if(!tempque.includes(ROBJ[J].question )) { 
                                    question1.push( question1.length+1 + ")  " + temp)
                                                    curma +=2 
                                                    tempque.push(ROBJ[J].question )
                                                    console.log(R2,curma)
                                                }else i-- 
                                            } else i--
                                        }
                                }
                            }
                        }
                        curma =0 
                        if(curma == 0 && curma< 16 ){
                         
                            var RQ4 = ROBJ.filter(object => object.marks == 4);
                            if (RQ4.length < 5) {
                                question2.push("not sufficent question in db <br/>")
                                question2.push("not sufficent question in db <br/> ")
                                question2.push("not sufficent question in db <br/> ")
                                question2.push("not sufficent question in db <br/> ") 
                                curma = 16
                                console.log("ok")
                            }
                            else{
                                
                                var tempque = []
                                while (curma < 16){
                                    for(i=1; i <= 4; i++){
                                        const J = Math.floor(Math.random() * ROBJ.length);
                                        if(ROBJ != undefined && ROBJ[J].marks==4 && ROBJ[J].question!=undefined){ 
                                            let temp =  " " + ROBJ[J].question  + " "+'<br>' +answers
                                            if(!tempque.includes(ROBJ[J].question))
                                            {
                                                question2.push( question2.length+1+")  " +temp)
                                                curma += 4
                                                tempque.push(ROBJ[J].question)
                                                console.log( "this is ok ")
                                            }else i--
                                        }else i--
                                    }
                                }
                            }
                        }
                        if(question2.length == 4 && question3.length <= 4){
                        var AQ4 = AOBJ.filter(object => object.marks == 4);
                        if (AQ4.length <= 4) {
                            question3.push("not sufficent question in db  <br/> ")
                            question3.push("not sufficent question in db  <br/> ")
                            question3.push("not sufficent question in db  <br/> ")
                            question3.push("not sufficent question in db  <br/> ")
                        }
                        else{
                            var tempque = [] 
                            curma =0 
                            console.log(curma)
                            while (curma < 16){
                                if(curma<16){
                                    for(i=1; i <= 1; i++){
                                        const J = Math.floor(Math.random() * AOBJ.length);
                                        if(AOBJ != undefined && AOBJ[J].marks==4 && AOBJ[J].question!=undefined){ 
                                            let temp =  " " + AOBJ[J].question  + " "+'<br>' + answers
                                            if(!tempque.includes(AOBJ[J].question)){
                                                question3.push( question3.length+1+")  " + temp)
                                                tempque.push(AOBJ[J].question)
                                                curma += 4
                                                //   console.log( "Question three ok" )
                                                //   console.log(curma) 
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    // console.log(question3.length)
                    if (question3.length == 4 && question4.length <5 ) {
                        var UQ4 = UOBJ.filter(object => object.marks == 4);
                        if (UQ4.length < 5) {
                            question4.push("not sufficent question in db <br/>")
                            question4.push("not sufficent question in db <br/>")
                            question4.push("not sufficent question in db <br/>")
                            question4.push("not sufficent question in db <br/>")
                            question4.push("not sufficent question in db <br/>")
                            
                        }
                        else {
                            
                            curma =0
                            var tempque = []
                            while (curma < 20){
                                for(i=0; i <= 4; i++){
                                    const J = Math.floor(Math.random() * UOBJ.length);
                                    if(UOBJ != undefined && UOBJ[J].marks==4 && UOBJ[J].question!=undefined){ 
                                        console.log("Question 4 ok ")
                                        let temp =  " " + UOBJ[J].question  + " " + '<br>'  + answers
                                        // console.log( UOBJ[J].question )
                                        if(!tempque.includes(UOBJ[J].question )){
                                            question4.push(  question4.length+1+")  " + temp)
                                            tempque.push(UOBJ[J].question )
                                            curma =curma + 4 
                                        } else i--
                                    }else i--
                                }
                            }
                        }
                    }
                    if (question4.length==5){
            var queA = AOBJ.filter(object => object.marks == 6);
            var queB = UOBJ.filter(object => object.marks == 6);
            var queR = ROBJ.filter(object => object.marks == 6);
            if (queA.length <= 2){
                question5.push("unsufficient question in db <br/> ")
                question6.push("unsufficient question in db <br/> ")
                
            }
            else if (queB.length <=2){
                question5.push("unsufficient question in db <br/> ")
                question6.push("unsufficient question in db <br/> ")
                
            }
            else  if (queR.length <= 2){
                question5.push("unsufficient question in db <br/> ")
                question6.push("unsufficient question in db <br/>")
                
            }
            else{  
                curma = 0 
                let r1= 0
                let r2 =0 
                for(i=1; i<=1; i++){  
                    //   console.log('here is the problem ') 
                    r1= Math.floor(Math.random() * ROBJ.length);
                    r2= Math.floor(Math.random() * ROBJ.length);
                    if(ROBJ[r1].marks ==6 && ROBJ[r2].marks==6 ){
                        if(ROBJ[r1].question !== ROBJ[r2].question && ROBJ[r1].question!=undefined && ROBJ[r2].question!=undefined) {
                            //   console.log('this is a ', r1,r2 )
                            question5.push( question5.length+1+")  " +  ROBJ[r1].question+ "<br>" + answers);
                            question6.push( question6.length+1+")  " + ROBJ[r2].question +  "<br>" + answers);
                        }else i --
                    } else i--
                }
                
                let a1= 0
                let a2 =0    
                for(i=1; i<=1; i++){    
                    // console.log('here is the problem ') 
                    a1= Math.floor(Math.random() * AOBJ.length);
                    a2= Math.floor(Math.random() * AOBJ.length);
                    if(AOBJ[a1].question !== AOBJ[a2].question && AOBJ[a2].question!=undefined  && AOBJ[a1].question != undefined) {
                        if(AOBJ[a1].marks ==6 && AOBJ[a2].marks==6 ){
                            //   console.log('this is a ', a1,a2 )
                            question5.push( question5.length+1+")  " +  AOBJ[a1].question+ "<br>" + answers);
                                question6.push( question6.length+1+")  " + AOBJ[a2].question + "<br>" + answers);
                            }
                            
                            else i--
                        } else i-- 
                        
                    }
                    let u2 =0
                    let u1= 0
                    for(i=1; i<=1; i++){
                        u1= Math.floor(Math.random() * UOBJ.length);
                        u2 =Math.floor(Math.random() * UOBJ.length);
                        
                        if([u1] !== [u2]){  
                            if(UOBJ[u1].marks ==6 && UOBJ[u2].marks==6 && UOBJ[u1].question!= undefined   && UOBJ[u2].question!=undefined){
                                console.log("passed")
                                console.log('this is u' + u1,u2)
                                question5.push( question5.length+1+")  " +  UOBJ[u1].question + "<br>" + answers);
                                question6.push( question6.length+1+")  " + UOBJ[u2].question + "<br>" + answers);
                                
                            }
                            else i--
                        } else i-- 
                    }
                }
            }
            
            
            res.send(` <div class="header" style='display:flex flex-row '>
            <h1 align="right" style="margin-right:2vw">`+ subject + `</h1>
            <div style="display:flex;">
            <h3 align="right" style="margin-right:70vw"> 3 Hours /marks 70 </h3>
            <h3 style="font-weight:bold">  Seat number  - _ _ _ _ _ _ _ </h3> 
            </div>
            <hr>
            <h5>Instructions: </h5>
        (1) All questions are compulsory. <br>
        (2) Illustrate your answers with neat sketches whenever necessary. <br>
        (3) Figure to the right indicate full marks. <br>
        (4) Assume suitable fata if necessary. <br>
        (5) Preferably, write the answers in sequential order. <br>
        <hr>
            </div>
            <main align='left' style="margin-left:4vw">
            <br> <h2 align='left style="margin-left:4vw'>  
            Q1. Attempt any five of the following: (10Marks) </h2> 
            `+ question1.join(' ') +` 
            <h2>Q.2 Attempt any THREE of the following:  (12marks)</h2> <br> `+ 
            question2.join(' ') +`
            <h2>Q.3 Attempt any THREE of the following: (12marks) </h2> <br> `
            + question3.join(' ') + `
            <h2>Q.4 Attempt any THREE of the following: (12marks)</h2> <br> 
            `+ question4.join(' ') +` 
            <h2>Q.5 Attempt any TWO of the following:  (12marks)</h2> <br>` 
            + question5.join(' ') +`
            <h2>Q.6 Attempt any TWO of the following:  (12marks)</h2> <br>`
            + question6.join(' ') 
            +`</main> 
            <input id="printpagebutton" type="button" value="Print Question paper" style=' margin-top: 25px;' onclick="printpage()"/> </br>
            <button id="newpaper"  style='margin-top:25px;' onclick= "redicrect()"> genrate another paper </button>
            
            <script>
            function printpage() {
                //Get the print button and put it into a variable
                var newpaper = document.getElementById("newpaper");
                var printButton = document.getElementById("printpagebutton");
                //Set the print button visibility to 'hidden' 
                printButton.style.visibility = 'hidden';
                newpaper.style.visibility = 'hidden';
    
                //Print the page content
                window.print()
            printButton.style.visibility = 'visible';
            newpaper.style.visibility = 'visible';
        }
        function redicrect(){
            console.log("call")
            location.href="/genrate"
        }
        </script> `
        )}
    }
    senddat()}
    });
    });
	router.get('/login', (req, res, next) => {
        return res.render('login.ejs');
    });
    let otp = Math.floor(1000 + Math.random() * 9000);
	router.get('/otp', (req, res, next) => {
	User.findOne({ unique_id: req.session.userId }, (err, data) => {
    if (!data) {
        res.redirect('/');
        } else {
        var mailoption = {
				from: "adityasharma3819@gmail.com",
				to: data.email,
				subject: otp,
				html: "This is your otp don't Share it with anyone please.."+otp
		        }
			smtpProtocol.sendMail(mailoption, function(err, response){
			if(err) {
			console.log(err);
	        } 
            console.log('Message Sent' );
			smtpProtocol.close();
        });
        console.log("this is your otp : ",otp , "\n to" , data.email)
		    return res.render('otp.ejs');
            }
            });
            });
	router.post('/otp', (req, res, next) => {
        User.findOne({ unique_id: req.session.userId }, (err, data) => {
            if (!data) {
                res.redirect('/');
            } else {
                console.log(req.body)
                console.log(otp, req.body.otp);
                if(otp == req.body.otp ){
                    res.send({ "Success": "Success!" });
				}
				else {
                    res.send({ "Success": "Wrong password!" });
				}
            }
        });
     });
	// -------------------------------------
	let otp1 = Math.floor(1000 + Math.random() * 9000);
	router.get('/otp1', (req, res, next) => {
        User.findOne({ unique_id: req.session.userId }, (err, data) => {
            if (!data) {
                res.redirect('/');
            }
            else {    
		return res.render('otp1.ejs');
        }
        }); 
        });
	router.post('/otp1', (req, res, next) => {
            console.log(req.body)
            console.log(otp1, req.body.otp);
            if(otp1 == req.body.otp ){
                res.send({ "Success": "Success!" });
            }
            else {
                res.send({ "Success": "Wrong password!" });
            }
        });
	// ---------------------------------
	router.post('/login', (req, res, next) => {
		User.findOne({ username : req.body.email}, (err, data) => {
		if (data) {
			let otp = Math.floor(1000 + Math.random() * 9000);
			if (data.password == req.body.password) {
				req.session.userId = data.unique_id;		
				// if(otp == req.body.otp ){
				// }
				res.send({ "Success": "Success!" });
					
			} else {
				res.send({ "Success": "Wrong password!" });
			}
		} else {
			res.send({ "Success": "This Email Is not regestered!" });
		}
	});
});
router.get('/admin', (req, res, next) => {
    User.findOne({ unique_id: req.session.userId }, (err, data) => {
		if (!data) {
			res.redirect('/');
		} else {
            return res.render('admin.ejs');
        }
	});
});
router.get('/genrate', (req, res, next) => {
	User.findOne({ unique_id: req.session.userId }, (err, data) => {
		if (!data) {
			res.redirect('/');
		} else {
            
    context.count = req.session.count;
    req.session.count = context.count + 1;
console.log(req.session.count)
            return res.render('genrate.ejs' , { files: dataview });
        }
	});
});
var marks = null
var chapters1 = null
var subject = null
let sturctchapter1 = {
    R:0,
    A2:0,
    A4:0,
    U4:0,
    A6:0,
    U6:0
}
let sturctchapter2 = {
    R:0,
    A2:0,
    A4:0,
    U4:0,
    A6:0,
    U6:0
}
let sturctchapter3 = {
    R:0,
    A2:0,
    A4:0,
    U4:0,
    A6:0,
    U6:0

}
let sturctchapter4 = {
    R:0,
    A2:0,
    A4:0,
    U4:0,
    A6:0,
    U6:0
}
let sturctchapter5 = {
    R:0,
    A2:0,
    A4:0,
    U4:0,
    A6:0,
    U6:0
}
let sturctchapter6 = {
    R:0,
    A2:0,
    A4:2,
    U4:2,
    A6:1,
    U6:0
}
router.post('/genrate', (req, res, next) => {
	User.findOne({ unique_id: req.session.userId }, (err, data) => {
        sturctchapter1['R'] = Number(req.body.R2chap1)
    sturctchapter1['A2'] = Number(req.body.A2chap1)
    sturctchapter1['A4'] = Number(req.body.A4chap1)
    sturctchapter1['U4'] = Number(req.body.U4chap1)
    sturctchapter1['A6'] = Number(req.body.A6chap1)
    sturctchapter1['U6'] = Number(req.body.U6chap1)
    sturctchapter2['R'] = Number(req.body.R2chap2)
  sturctchapter2['A2'] = Number(req.body.A2chap2)
  sturctchapter2['A4'] = Number(req.body.A4chap2)
  sturctchapter2['U4'] = Number(req.body.U4chap2)
  sturctchapter2['A6'] = Number(req.body.A6chap2)
  sturctchapter2['U6'] = Number(req.body.U6chap2)
  sturctchapter3['R']  = Number(req.body.R2chap3)
  sturctchapter3['A2'] = Number(req.body.A2chap3)
  sturctchapter3['A4'] = Number(req.body.A4chap3)
  sturctchapter3['U4'] = Number(req.body.U4chap3)
  sturctchapter3['A6'] = Number(req.body.A6chap3)
  sturctchapter3['U6'] = Number(req.body.U6chap3)
  sturctchapter4['R']  =  Number(req.body.R2chap4)
  sturctchapter4['A2'] = Number(req.body.A2chap4)
  sturctchapter4['A4'] = Number(req.body.A4chap4)
  sturctchapter4['U4'] = Number(req.body.U4chap4)
  sturctchapter4['A6'] = Number(req.body.A6chap4)
  sturctchapter4['U6'] = Number(req.body.U6chap4)
  sturctchapter5['R'] = Number(req.body.R2chap5)
  sturctchapter5['A2'] = Number(req.body.A2chap5)
  sturctchapter5['A4'] = Number(req.body.A4chap5)
  sturctchapter5['U4'] = Number(req.body.U4chap5)
  sturctchapter5['A6'] = Number(req.body.A6chap5)
  sturctchapter5['U6'] = Number(req.body.U6chap5)
  sturctchapter6['R'] = Number(req.body.R2chap6)
  sturctchapter6['A2'] = Number(req.body.A2chap6)
  sturctchapter6['A4'] = Number(req.body.A4chap6)
  sturctchapter6['U4'] =Number(req.body.U4chap6)
  sturctchapter6['A6'] =Number(req.body.A6chap6)
  sturctchapter6['U5'] =Number(req.body.U6chap6 )  
  console.log("this is :" , sturctchapter1['R'] , sturctchapter1['A2'])
   let sum = sturctchapter1.A4+sturctchapter2.A4+sturctchapter3.A4+sturctchapter4.A4+sturctchapter5.A4+sturctchapter6.A4 
let sum1 = sturctchapter1.U4+sturctchapter2.U4+sturctchapter3.U4+sturctchapter4.U4+sturctchapter5.U4+sturctchapter6.U4 
let sum2 = sturctchapter1.A6+sturctchapter2.A6+sturctchapter3.A6+sturctchapter4.A6+sturctchapter5.A6+sturctchapter6.A6 
let sum3 = sturctchapter1.U6+sturctchapter2.U6+sturctchapter3.U6+sturctchapter4.U6+sturctchapter5.U6+sturctchapter6.U6 
let rsum = sturctchapter1.R+sturctchapter2.R+sturctchapter3.R+sturctchapter4.R+sturctchapter5.R+sturctchapter6.R 
let A2sum = sturctchapter1.A2+sturctchapter2.A2+sturctchapter3.A2+sturctchapter4.A2+sturctchapter5.A2+sturctchapter6.A2 
console.log('sum is:',rsum + A2sum )
let Subject = req.body.subject
let file_name = __dirname+'\\public\\paper\\'+Subject+'.xlsx'
// console.log(Subject)
const workbook = xlsx.readFile(file_name);
// Get the sheet names from the workbook
const sheetNames = workbook.SheetNames;
// Loop through each sheet and store its data in a variable
for (let i = 0; i < sheetNames.length; i++) {
  const sheetName = sheetNames[i];
  const worksheet = workbook.Sheets[sheetName];
  const sheetData = xlsx.utils.sheet_to_json(worksheet);
  // Store the sheet data in a variable with the sheet name as the variable name
  eval(`var ${sheetName} = ${JSON.stringify(sheetData)}`);
}

curma = 0 
let papermarks = req.body.Marks
if (papermarks==20){
    let R2question =[]
    while(R2question.length<rsum){
        for (i= 1; i<=sturctchapter1.R;i++){
            let J = Math.floor(Math.random() * chapter1.length);
            if(chapter1[J].marks==2&& i<=sturctchapter1.R){
                R2question.push(chapter1[J])
                curma+=2
            }
            else i--
        }
        for (i= 1; i<=sturctchapter2.R;i++){
            let J = Math.floor(Math.random() * chapter2.length);
            if(chapter2[J].marks==2 && i<=sturctchapter2.R){
                R2question.push(chapter2[J])
                curma+=2
            }
            else i--
        }for (i= 1; i<=sturctchapter3.R;i++){
            let J = Math.floor(Math.random() * chapter3.length);
            if(chapter3[J].marks==2 && i<=sturctchapter3.R){
                R2question.push(chapter3[J])
                curma+=2
            }
            else i--
        }for (i=1; i<= sturctchapter4.R;i++){
            let J = Math.floor(Math.random() * chapter4.length);
            if(chapter4[J].marks==2 && i<=sturctchapter4.R){
                R2question.push(chapter4[J])
                curma+=2   
            }
            else i--
        }for (i= 1; i<=sturctchapter5.R;i++){
            let J = Math.floor(Math.random() * chapter5.length);
            if(chapter5[J].marks==2 &&  i<=sturctchapter5.R){
                R2question.push(chapter5[J])
                curma+=2
                
            }else i--
        }
        for (i= 1; i<=sturctchapter6.R;i++){
            let J = Math.floor(Math.random() * chapter6.length);
            if(chapter6[J].marks==2 ){
                R2question.push(chapter6[J])
                curma+=2
            }else i--
        }
    }
    let A2question =[]
curma = 0
// question 1
while(A2question.length<A2sum){
    for (i= 1; i<=sturctchapter1.A2;i++){
        let J = Math.floor(Math.random() * chapter1.length);
        if(chapter1[J].marks==2&& i<=sturctchapter1.A2){
            A2question.push(chapter1[J])
            curma+=2
        }
        else i--
    }
    for (i= 1; i<=sturctchapter2.A2;i++){
        let J = Math.floor(Math.random() * chapter2.length);
        if(chapter2[J].marks==2 && i<=sturctchapter2.A2){
            A2question.push(chapter2[J])
            curma+=2
        }
        else i--
    }for (i= 1; i<=sturctchapter3.A2;i++){
        let J = Math.floor(Math.random() * chapter3.length);
        if(chapter3[J].marks==2 && i<=sturctchapter3.A2){
            A2question.push(chapter3[J])
            curma+=2
        }
        else i--
    }for (i=1; i<= sturctchapter4.A2;i++){
        let J = Math.floor(Math.random() * chapter4.length);
        if(chapter4[J].marks==2 && i<=sturctchapter4.A2){
            A2question.push(chapter4[J])
            curma+=2   
        }
        else i--
    }for (i= 1; i<=sturctchapter5.A2;i++){
        let J = Math.floor(Math.random() * chapter5.length);
        if(chapter5[J].marks==2 &&  i<=sturctchapter5.A2){
            A2question.push(chapter5[J])
            curma+=2
            
        }else i--
    }
    for (i= 1; i<=sturctchapter6.A2;i++){
        let J = Math.floor(Math.random() * chapter6.length);
        if(chapter6[J].marks==2 ){
            A2question.push(chapter6[J])
            curma+=2
        }else i--
    }
}

//Question 2
let Aquestion4 = [];
while(Aquestion4.length<sum){  
    for (i= 1; i<=sturctchapter1.A4; i++){
        let J = Math.floor(Math.random() * chapter1.length);
        if(chapter1[J].marks==4&& i<=sturctchapter1.A4){
            Aquestion4.push(chapter1[J])
        }
        else i--
    }
    for (i= 1; i<=sturctchapter2.A4;i++){
        let J = Math.floor(Math.random() * chapter2.length);
        if(chapter2[J].marks==4 && i<=sturctchapter2.A4){
            Aquestion4.push(chapter2[J])
            curma+=2
        }
        else i--
    }
    for (i= 1; i<=sturctchapter3.A4;i++){
        let J = Math.floor(Math.random() * chapter3.length);
        if(chapter3[J].marks==4 && i<=sturctchapter3.A4){
            Aquestion4.push(chapter3[J])
            curma+=2
        }
        else i--
    }
    for (i=1; i<= sturctchapter4.A4;i++){
        let J = Math.floor(Math.random() * chapter4.length);
        if(chapter4[J].marks==4 && i<=sturctchapter4.A4){
            Aquestion4.push(chapter4[J])
            curma+=2   
        }
        else i--
    }for (i= 1; i<=sturctchapter5.A4;i++){
        let J = Math.floor(Math.random() * chapter5.length);
        if(chapter5[J].marks==4 &&  i<=sturctchapter5.A4){
            Aquestion4.push(chapter5[J])
            curma+=2
            
        }else i--
    }
    for (i= 1; i<=sturctchapter6.A4;i++){
        let J = Math.floor(Math.random() * chapter6.length);
        if(chapter6[J].marks==4 ){
            Aquestion4.push(chapter6[J])
            curma+=2
        }else i--
    }
}
//U4
let Uquestion4 = [];
while(Uquestion4.length<sum1){  
    for (i= 1; i<=sturctchapter1.U4;i++){
        let J = Math.floor(Math.random()*chapter1.length);
        if(chapter1[J].marks==4&& i<=sturctchapter1.U4){
            Uquestion4.push(chapter1[J])
        }
        else i--
    }
    for (i= 1; i<=sturctchapter2.U4;i++){
        let J = Math.floor(Math.random() * chapter2.length);
        if(chapter2[J].marks==4 && i<=sturctchapter2.U4){
            Uquestion4.push(chapter2[J])
            curma+=2
        }
        else i--
    }
    for(i= 1; i<=sturctchapter3.U4;i++){
        let J = Math.floor(Math.random() * chapter3.length);
        if(chapter3[J].marks==4 && i<=sturctchapter3.U4){
            Uquestion4.push(chapter3[J])
            curma+=2
        }
        else i--
    }
    for (i=1; i<= sturctchapter4.U4;i++){
        let J = Math.floor(Math.random() * chapter4.length);
        if(chapter4[J].marks==4 && i<=sturctchapter4.U4){
            Uquestion4.push(chapter4[J])
            curma+=2   
        }
        else i--
    }for (i= 1; i<=sturctchapter5.U4;i++){
        let J = Math.floor(Math.random() * chapter5.length);
        if(chapter5[J].marks==4 &&  i<=sturctchapter5.U4){
            Uquestion4.push(chapter5[J])
            curma+=2
            
        }else i--
    }
    for (i= 1; i<=sturctchapter6.U4;i++){
        let J = Math.floor(Math.random() * chapter6.length);
        if(chapter6[J].marks==4 ){
            Uquestion4.push(chapter6[J])
            curma+=2
        }else i--
    }
}


    let data =[] ;
    R2question.forEach(element => {
        // console.log('element',element)
        data.push(element.question +  "<br>")
    })
    let data1 = +[]
    Aquestion4.forEach(element => {
        // console.log('element',element)
        data1.push(element.question + "<br>")
    })
    let data2 =[]
    Uquestion4.forEach(element => {
        // console.log('element',element)
        data2.push(element.question +"<br>")
    })
    let A2questiondata = []
    A2question.forEach(element => {
        // console.log('element',element)
        A2questiondata.push(element.question + "<br>")
    })
    let question1r = data.concat(A2questiondata)
    let question1 =[]
    question1r.forEach(element => {
        question1.push(question1.length+1+ ')' +element)       
    });
    let marque4 =  data1.concat(data2)
    let question2 = []
    marque4.forEach(element => {
        question2.push(question2.length+1+ ')' +element)         
    });
res.send( ` <div class="header" style='display:flex flex-row '>
    <h1 align="right" style="margin-right:2vw">`+ 22025 + `</h1>
    <div style="display:flex;">
    <h3 align="right" style="margin-right:70vw"> 3 Hours /marks 70 </h3>
    <h3 style="font-weight:bold">  Seat number  - _ _ _ _ _ _ _ </h3> 
    </div>
    <hr>
    <h5>Instructions: </h5>
(1) All questions are compulsory. <br>
(2) Illustrate your answers with neat sketches whenever necessary. <br>
(3) Figure to the right indicate full marks. <br>
(4) Assume suitable fata if necessary. <br>
(5) Preferably, write the answers in sequential order. <br>
<hr>
    </div>
    <main align='left' style="margin-left:4vw">
    <br> <h2 align='left style="margin-left:4vw'>  
    Q1. Attempt any Four of the following: (8Marks) </h2> 
    `+  question1.join(' ') + `
    <br> <h2 align='left style="margin-left:4vw'>  
    Q2. Attempt any Three of the following: (12Marks) </h2> 
    `+question2.join(' ') )
   
}

if (papermarks == 70){

let R2question =[]
curma = 0
// question 1

while(R2question.length<rsum){
    for (i= 1; i<=sturctchapter1.R;i++){
        let J = Math.floor(Math.random() * chapter1.length);
        if(chapter1[J].marks==2&& i<=sturctchapter1.R){
            R2question.push(chapter1[J])
            curma+=2
        }
        else i--
    }
    for (i= 1; i<=sturctchapter2.R;i++){
        let J = Math.floor(Math.random() * chapter2.length);
        if(chapter2[J].marks==2 && i<=sturctchapter2.R){
            R2question.push(chapter2[J])
            curma+=2
        }
        else i--
    }for (i= 1; i<=sturctchapter3.R;i++){
        let J = Math.floor(Math.random() * chapter3.length);
        if(chapter3[J].marks==2 && i<=sturctchapter3.R){
            R2question.push(chapter3[J])
            curma+=2
        }
        else i--
    }for (i=1; i<= sturctchapter4.R;i++){
        let J = Math.floor(Math.random() * chapter4.length);
        if(chapter4[J].marks==2 && i<=sturctchapter4.R){
            R2question.push(chapter4[J])
            curma+=2   
        }
        else i--
    }for (i= 1; i<=sturctchapter5.R;i++){
        let J = Math.floor(Math.random() * chapter5.length);
        if(chapter5[J].marks==2 &&  i<=sturctchapter5.R){
            R2question.push(chapter5[J])
            curma+=2
            
        }else i--
    }
    for (i= 1; i<=sturctchapter6.R;i++){
        let J = Math.floor(Math.random() * chapter6.length);
        if(chapter6[J].marks==2 ){
            R2question.push(chapter6[J])
            curma+=2
        }else i--
    }
}
let A2question =[]
curma = 0
// question 1
while(A2question.length<A2sum){
    for (i= 1; i<=sturctchapter1.A2;i++){
        let J = Math.floor(Math.random() * chapter1.length);
        if(chapter1[J].marks==2&& i<=sturctchapter1.A2){
            A2question.push(chapter1[J])
            curma+=2
        }
        else i--
    }
    for (i= 1; i<=sturctchapter2.A2;i++){
        let J = Math.floor(Math.random() * chapter2.length);
        if(chapter2[J].marks==2 && i<=sturctchapter2.A2){
            A2question.push(chapter2[J])
            curma+=2
        }
        else i--
    }for (i= 1; i<=sturctchapter3.A2;i++){
        let J = Math.floor(Math.random() * chapter3.length);
        if(chapter3[J].marks==2 && i<=sturctchapter3.A2){
            A2question.push(chapter3[J])
            curma+=2
        }
        else i--
    }for (i=1; i<= sturctchapter4.A2;i++){
        let J = Math.floor(Math.random() * chapter4.length);
        if(chapter4[J].marks==2 && i<=sturctchapter4.A2){
            A2question.push(chapter4[J])
            curma+=2   
        }
        else i--
    }for (i= 1; i<=sturctchapter5.A2;i++){
        let J = Math.floor(Math.random() * chapter5.length);
        if(chapter5[J].marks==2 &&  i<=sturctchapter5.A2){
            A2question.push(chapter5[J])
            curma+=2
            
        }else i--
    }
    for (i= 1; i<=sturctchapter6.A2;i++){
        let J = Math.floor(Math.random() * chapter6.length);
        if(chapter6[J].marks==2 ){
            A2question.push(chapter6[J])
            curma+=2
        }else i--
    }
}
//Question 2
let Aquestion4 = [];
while(Aquestion4.length<sum){  
    for (i= 1; i<=sturctchapter1.A4; i++){
        let J = Math.floor(Math.random() * chapter1.length);
        if(chapter1[J].marks==4&& i<=sturctchapter1.A4){
            Aquestion4.push(chapter1[J])
        }
        else i--
    }
    for (i= 1; i<=sturctchapter2.A4;i++){
        let J = Math.floor(Math.random() * chapter2.length);
        if(chapter2[J].marks==4 && i<=sturctchapter2.A4){
            Aquestion4.push(chapter2[J])
            curma+=2
        }
        else i--
    }
    for (i= 1; i<=sturctchapter3.A4;i++){
        let J = Math.floor(Math.random() * chapter3.length);
        if(chapter3[J].marks==4 && i<=sturctchapter3.A4){
            Aquestion4.push(chapter3[J])
            curma+=2
        }
        else i--
    }
    for (i=1; i<= sturctchapter4.A4;i++){
        let J = Math.floor(Math.random() * chapter4.length);
        if(chapter4[J].marks==4 && i<=sturctchapter4.A4){
            Aquestion4.push(chapter4[J])
            curma+=2   
        }
        else i--
    }for (i= 1; i<=sturctchapter5.A4;i++){
        let J = Math.floor(Math.random() * chapter5.length);
        if(chapter5[J].marks==4 &&  i<=sturctchapter5.A4){
            Aquestion4.push(chapter5[J])
            curma+=2
            
        }else i--
    }
    for (i= 1; i<=sturctchapter6.A4;i++){
        let J = Math.floor(Math.random() * chapter6.length);
        if(chapter6[J].marks==4 ){
            Aquestion4.push(chapter6[J])
            curma+=2
        }else i--
    }
}
//U4
let Uquestion4 = [];
while(Uquestion4.length<sum1){  
    for (i= 1; i<=sturctchapter1.U4;i++){
        let J = Math.floor(Math.random()*chapter1.length);
        if(chapter1[J].marks==4&& i<=sturctchapter1.U4){
            Uquestion4.push(chapter1[J])
        }
        else i--
    }
    for (i= 1; i<=sturctchapter2.U4;i++){
        let J = Math.floor(Math.random() * chapter2.length);
        if(chapter2[J].marks==4 && i<=sturctchapter2.U4){
            Uquestion4.push(chapter2[J])
            curma+=2
        }
        else i--
    }
    for(i= 1; i<=sturctchapter3.U4;i++){
        let J = Math.floor(Math.random() * chapter3.length);
        if(chapter3[J].marks==4 && i<=sturctchapter3.U4){
            Uquestion4.push(chapter3[J])
            curma+=2
        }
        else i--
    }
    for (i=1; i<= sturctchapter4.U4;i++){
        let J = Math.floor(Math.random() * chapter4.length);
        if(chapter4[J].marks==4 && i<=sturctchapter4.U4){
            Uquestion4.push(chapter4[J])
            curma+=2   
        }
        else i--
    }for (i= 1; i<=sturctchapter5.U4;i++){
        let J = Math.floor(Math.random() * chapter5.length);
        if(chapter5[J].marks==4 &&  i<=sturctchapter5.U4){
            Uquestion4.push(chapter5[J])
            curma+=2
            
        }else i--
    }
    for (i= 1; i<=sturctchapter6.U4;i++){
        let J = Math.floor(Math.random() * chapter6.length);
        if(chapter6[J].marks==4 ){
            Uquestion4.push(chapter6[J])
            curma+=2
        }else i--
    }
}

//A6
let Aquestion6 = [];
while(Aquestion6.length<sum2){  
    for (i= 1; i<=sturctchapter1.A6; i++){
        let J = Math.floor(Math.random() * chapter1.length);
        if(chapter1[J].marks==6 && i<=sturctchapter1.A6){
            Aquestion6.push(chapter1[J])
        }
        else i--
    }
    for (i= 1; i<=sturctchapter2.A6;i++){
        let J = Math.floor(Math.random() * chapter2.length);
        if(chapter2[J].marks==6 && i<=sturctchapter2.A6){
            Aquestion6.push(chapter2[J])
            curma+=2
        }
        else i--
    }
    for (i= 1; i<=sturctchapter3.A6;i++){
        let J = Math.floor(Math.random() * chapter3.length);
        if(chapter3[J].marks==6 && i<=sturctchapter3.A6){
            Aquestion6.push(chapter3[J])
            curma+=2
        }
        else i--
    }
    for (i=1; i<= sturctchapter4.A6;i++){
        let J = Math.floor(Math.random() * chapter4.length);
        if(chapter4[J].marks==6 && i<=sturctchapter4.A6){
            Aquestion6.push(chapter4[J])
            curma+=2   
        }
        else i--
    }for (i= 1; i<=sturctchapter5.A6;i++){
        let J = Math.floor(Math.random() * chapter5.length);
        if(chapter5[J].marks==6 &&  i<=sturctchapter5.A6){
            Aquestion6.push(chapter5[J])
            curma+=2
        }else i--
    }
    for (i= 1; i<=sturctchapter6.A6;i++){
        let J = Math.floor(Math.random() * chapter6.length);
        if(chapter6[J].marks==6 ){
            Aquestion6.push(chapter6[J])
            curma+=2
        }else i--
    }
}
//U4
let Uquestion6 = [];
while(Uquestion6.length < sum3){  
    for (i= 1; i<=sturctchapter1.U6;i++){
        let J = Math.floor(Math.random()*chapter1.length);
        if(chapter1[J].marks==6&& i<=sturctchapter1.U6){
            Uquestion6.push(chapter1[J])
        }
        else i--
    }
    for (i= 1; i<=sturctchapter2.U6;i++){
        let J = Math.floor(Math.random() * chapter2.length);
        if(chapter2[J].marks==6 && i<=sturctchapter2.U6){
            Uquestion6.push(chapter2[J])
            curma+=2
        }
        else i--
    }
    for(i= 1; i<=sturctchapter3.U6;i++){
        let J = Math.floor(Math.random() *chapter3.length);
        if(chapter3[J].marks==6 && i<=sturctchapter3.U6){
            Uquestion6.push(chapter3[J])
            curma+=2
        }
        else i--
    }
    for (i=1; i<= sturctchapter4.U6;i++){
        let J = Math.floor(Math.random() * chapter4.length);
        if(chapter4[J].marks==6 && i<=sturctchapter4.U6){
            Uquestion6.push(chapter4[J])
            curma+=2   
        }
        else i--
    }for (i= 1; i<=sturctchapter5.U6;i++){
        let J = Math.floor(Math.random() * chapter6.length);
        if(chapter5[J] != undefined){

            if(chapter5[J].marks==6 &&  i<=sturctchapter5.U6){
                Uquestion6.push(chapter5[J])
                curma+=2
            }else i--
        }else i--
    }
    for (i= 1; i<=sturctchapter6.U6;i++){
        let J = Math.floor(Math.random() * chapter6.length);
        if(chapter6[J].marks==6 ){
            Uquestion6.push(chapter6[J])
            curma+=2
        }else i--
    }
}

// console.log('ok')  
// console.log(sum3)
// console.log(Uquestion6.length , Aquestion6)
// console.log(R2question.length)
// console.log(question1[1].chapter)

    let data =[] ;
    R2question.forEach(element => {
        // console.log('element',element)
        data.push(element.question + element.chapter +element.marks+ "<br>")
    })
    let data1 = []
    Aquestion4.forEach(element => {
        // console.log('element',element)
        data1.push(element.question + element.chapter +element.marks + "<br>")
    })
    let data2 =[]
    Uquestion4.forEach(element => {
        // console.log('element',element)
        data2.push(element.question + element.chapter +element.marks + "<br>")
    })
    let data3 =[]
    Uquestion6.forEach(element => {
        // console.log('element',element)
        data3.push(element.question + element.chapter+ " " +element.marks + "<br>")
    })
    let data4 =[]
    Aquestion6.forEach(element => {
        // console.log('element',element)
        data4.push(element.question + element.chapter +element.marks + "<br>")
    })
    let A2questiondata = []
    A2question.forEach(element => {
        // console.log('element',element)
        A2questiondata.push(element.question + element.chapter +element.marks + "<br>")
    })
    // ------------------------------------------------------------------------------------------------------
    let question1 = data.concat(A2questiondata)
    let marque4 =  Aquestion4.concat(Uquestion4) 
    // console.log('this is marque ', marque4)
    let a1= 0
    let a2 =0
    let a3 = 0 
    let final4 =  marque4.sort((a, b) => 0.5 - Math.random());
    let question2 = [] 
    let question3 = []
    let question4 = []
   
    for(let i=1; i<=4; i++){  
        question2.push(
            question2.length+1+")  " + final4[i].question+ "<br>"
            )    
    } 
    for(let i=5; i<=8; i++){
        question3.push(
            question3.length+1+")  " + final4[i].question+ "<br>" )
    }
    for(let i=9; i<=12; i++){
        question4.push(
        question4.length+1+")  " + final4[i].question+ "<br>")
    }
    let data6 = Uquestion6.concat(Aquestion6)
        // console.log('data 6 is ' , data6)
        let r1= 0
        let r2 =0 
        let r16q = []
        let r26q = []
        let question5 = []
        let question6 = []
        // console.log(data6[r1])
        for(i=1; i<=3; i++){  
                    //   console.log('here is the problem '
                    r1= Math.floor(Math.random() * data6.length);
                    r2= Math.floor(Math.random() * data6.length);
                    if(data6[r1]!=undefined && data6[r2]!=undefined&&
                        data6[r1].question !== data6[r2].question&&
                             marque4[r1].question!=undefined &&
                            marque4[r2].question!=undefined &&
                            !r16q.includes(marque4[r1].question)&&
                            !r26q.includes(marque4[r2].question)
                            ){
                            question5.push( question5.length+1+")  " +  data6[r1].question+ "<br>" );
                            r16q.push(data6[r1].question)
                            question6.push( question6.length+1+")  " + data6[r2].question +  "<br>");
                            r26q.push(data6[r2].question)
                            } else i--
                            console.log('problem')
                        }
    // let question2 = data1.concat(data2)
res.send(
     ` <div class="header" style='display:flex flex-row '>
    <h1 align="right" style="margin-right:2vw">`+ 22025 + `</h1>
    <div style="display:flex;">
    <h3 align="right" style="margin-right:70vw"> 3 Hours /marks 70 </h3>
    <h3 style="font-weight:bold">  Seat number  - _ _ _ _ _ _ _ </h3> 
    </div>
    <hr>
    <h5>Instructions: </h5>
(1) All questions are compulsory. <br>
(2) Illustrate your answers with neat sketches whenever necessary. <br>
(3) Figure to the right indicate full marks. <br>
(4) Assume suitable fata if necessary. <br>
(5) Preferably, write the answers in sequential order. <br>
<hr>
    </div>
    <main align='left' style="margin-left:4vw">
    <br> <h2 align='left style="margin-left:4vw'>  
    Q1. Attempt any five of the following: (10Marks) </h2> 
    `+  question1.join(' ') + `
   <br><br> <h2 align='left style="margin-left:4vw'>
    Q2. Attempt any Three of the following: (12Marks) </h2> ${question2.join(' ')}
    <h2 align='left style="margin-left:4vw'>
    Q3. Attempt any Three of the following: (12Marks) </h2> ${question3.join(' ')}
    <h2 align='left style="margin-left:4vw'>
    Q4. Attempt any Three of the following: (12Marks) </h2> ${question4.join(' ')}  
    <h2 align='left style="margin-left:4vw'>
    Q5. Attempt any Two of the following: (12Marks) </h2> ${question5.join(' ')}
    <h2 align='left style="margin-left:4vw'>
    Q6. Attempt any Two of the following: (12Marks) </h2> ${question6.join(' ')}`)  
}
})

});
  

router.get('/genratepep', (req, res, next) => {
	User.findOne({ unique_id: req.session.userId }, (err, data) => {
		if (!data) {
			res.redirect('/');
		} else {
            async function senddat(){         
                console.log(chapters1, subject)
                async function gendata(){
                    let data = [] 
                    var chars = chapters1
                    let file_name = __dirname+'\\public\\paper\\'+subject+'.xlsx'
                    let workbook = xlsx.readFile(file_name);
                    if(chars.length < 8){
                        for(let i=0; i<chars.length; i++){
                            let sheetName = chars[i];
                            let sheet = workbook.Sheets[sheetName]; 
                            console.log(sheetName)
                            let jsonData = xlsx.utils.sheet_to_json(sheet);
                            for( var j in jsonData){    
                                data.push(jsonData[j])
                            }
                            //   console.log("data",data)
                            
                        }
                    }
                    else{
                        let sheetName = chars;
                        // console.log(chars.length , chars)
                        let sheet = workbook.Sheets[sheetName];
                        let jsonData = xlsx.utils.sheet_to_json(sheet);
                        for( var j in jsonData){    
                            data.push(jsonData[j])
                        } 
                        console.log( sheetName )
                    }
                    return data;  
                }
                let R2 = 0
                // console.log(R4,A4,U4)
                let data1 = await gendata();
                console.log(data1)
                let ROBJ = null
                ROBJ =data1.filter(object => object.category == "R");
                let AOBJ =  null
                AOBJ =  data1.filter(object => object.category == "A");
                let UOBJ = null
                UOBJ =  data1.filter(object => object.category == "U");
                // console.log(UOBJ) 
                let curma = 0;
                let question1 = []
                let question2 = []
                let question3 = []
                let question4 = []
                let question5 = []
                let question6 = []
                let arrayquestion = []
                var newdata = new Array()
                // console.log('XLSX files (global):', dataview);
                console.log(marks)
                if( marks ==20 ){
                    curma = 0 
                    R2 = 5
                    while (curma < 10 ){
                        console.log(R2,curma)
                        if( curma== 0 && curma < (R2*2)){
                            for(i=1; i <= R2; i++){
                                let J = Math.floor(Math.random() * ROBJ.length);
                                if(ROBJ != undefined && curma <= R2*2 && ROBJ[J].marks==2 && ROBJ[J].question!=undefined){
                             let temp =  " " +  ROBJ[J].question + " "+'<br>' 
                             if(!arrayquestion.includes(ROBJ[J].question)) {
                                 question1.push( question1.length+1 + ")  " + temp)
                                 arrayquestion.push(ROBJ[J].question )
                                 curma +=2 
                                }else i-- 
                            } else i--
                        }
                    }  
                }
                // 4marks question         
                //   console.log('this is final' , curma)   
                if(curma == 10){
                    curma = 0 
                    if(curma == 0 && !newdata.includes("<h2>Q.2 Attempt any THREE of the following: </h2> <br> ")){
                        //   console.log("nahi hua print ")
                        newdata.push("<h2>Q.2 Attempt any THREE of the following: (12 marks)</h2> <br> ")
                    }
                    while (curma < 16 ){
                        if(newdata.length==1 && newdata.length<2 ){
                            for(var i=1; i <= 2; i++){
                                // console.log(curma); 
                                let J = Math.floor(Math.random() * ROBJ.length);
                                if(ROBJ != undefined &&  ROBJ[J].marks==4 && ROBJ[J].question!=undefined){  
                                    let temp = newdata.length+") " + " " +  ROBJ[J].question + " "+'<br>' 
                                        if(!arrayquestion.includes(ROBJ[J].question  )) { 
                                            newdata.push( temp)
                                            curma +=4
                                            arrayquestion.push(ROBJ[J].question )
                                            // console.log("0k")
                                        }
                                    } else i--
                                }
                            }
                            if( newdata.length==2 && newdata.length<3)
                            {
                                for(i=1; i <= 2; i++){
                                    let J = Math.floor(Math.random() * AOBJ.length);
                                    if(AOBJ != undefined  && AOBJ[J].marks==4 && AOBJ[J].question){
                                        let temp =  newdata.length+")  " + " " +  AOBJ[J].question + " "+'<br>' 
                                        if(!arrayquestion.includes(AOBJ[J].question)) { 
                                            newdata.push( temp)
                                            arrayquestion.push(AOBJ[J].question )
                                            curma +=4
                                            // console.log("0k")
                                            // console.log(curma)
                                        }
                                    } else i--
                                }
                            }
                            else if(  newdata.length>= 3 && newdata.length <=4){
                                for(i=0; i < 2; i++)
                                {
                                    let J = Math.floor(Math.random() * UOBJ.length);
                    if(UOBJ != undefined  && UOBJ[J].marks==4 && curma<16 && UOBJ[J].question!=undefined){
                        let temp =  newdata.length+")  " +" " +  UOBJ[J].question + '<br>' 
                        if(!arrayquestion.includes(UOBJ[J].question)) { 
                            newdata.push( temp)
                            arrayquestion.push(UOBJ[J].question )
                            curma +=4
                        }
                    } 
                    
                }
                //   console.log(newdata.length)  
                
            }
        }
    }
    res.send(`
    <div class="header" style='display:flex flex-row '>
    <h1 align="right" style="margin-right:2vw">`+ subject + `</h1>
    <div style="display:flex;">
    <h3 align="right" style="margin-right:70vw"> 1 Hours/ marks 20 </h3>
    <h3 style="font-weight:bold">  Seat number - _ _ _ _ _ _ _ </h3> 
    </div>
    <hr>
    <h5>Instructions: </h5>
    (1) All questions are compulsory. <br>
    (2) Illustrate your answers with neat sketches whenever necessary. <br>
    (3) Figure to the right indicate full marks. <br>
    (4) Assume suitable fata if necessary. <br>
    (5) Preferably, write the answers in sequential order. <br>
    <hr>
    </div>` +
    ` <div style='margin-left:20px'>
    <h2> Q1. Attempt any four of the following: (8 marks) </h2> <main align='left '>` + 
    question1.join(' ') +newdata.join(' ') +
    `</main> 
    <input id="printpagebutton" type="button" value="Print Question paper" style=' margin-top: 25px;' onclick="printpage()"/>
    <button id="newpaper"  style='margin-top:25px;' onclick= "redirect()"> genrate another paper </button>
    <script>
    function printpage() {
        //Get the print button and put it into a variable
        var newpaper = document.getElementById("newpaper");
        var printButton = document.getElementById("printpagebutton");
        //Set the print button visibility to 'hidden' 
        printButton.style.visibility = 'hidden';
        newpaper.style.visibility = 'hidden';

        //Print the page content
        window.print()
    printButton.style.visibility = 'visible';
    newpaper.style.visibility = 'visible';

}
function redirect(){
location.href ="/genrate"
}
</script> `
	)}
	else if (marks==70)
    {
        curma = 0 
        R2 = 7
        while (curma < 14 ){ 
            var tempque = []
            if( curma== 0 && curma < (R2*2)){
                var RQ2 = ROBJ.filter(object => object.marks == 2);
                if (RQ2.length < 8) {
                    question1.push("not sufficent question in db <br/>")
                    question1.push("not sufficent question in db <br/> ")
                    question1.push("not sufficent question in db <br/> ")
                    question1.push("not sufficent question in db <br/> ")
                    question1.push("not sufficent question in db <br/> ")
                    question1.push("not sufficent question in db <br/> ")
                    question1.push("not sufficent question in db <br/> ")  
                    curma = 14
                    console.log("ok")
                }
                else{
                    for(i=1; i <= R2; i++){
                        let J = Math.floor(Math.random() * ROBJ.length);
                        if(ROBJ != undefined && curma <= R2*2 && ROBJ[J].marks==2 && ROBJ[J].question!=undefined){
                            let temp =  " " +  ROBJ[J].question + " "+'<br>' 
                            if(!tempque.includes(ROBJ[J].question )) { 
                                question1.push( question1.length+1 + ")  " + temp)
                                                curma +=2 
                                                tempque.push(ROBJ[J].question )
                                                console.log(R2,curma)
                                            }else i-- 
                                        } else i--
                                    }
                            }
                        }
                    }
                    curma =0 
                    if(curma == 0 && curma< 16 ){
                        var RQ4 = ROBJ.filter(object => object.marks == 4);
                        if (RQ4.length < 5) {
                            question2.push("not sufficent question in db <br/>")
                            question2.push("not sufficent question in db <br/> ")
                            question2.push("not sufficent question in db <br/> ")
                            question2.push("not sufficent question in db <br/> ") 
                            curma = 16
                            console.log("ok")
                        }
                        else{
                            
                            var tempque = []
                            while (curma < 16){
                                for(i=1; i <= 4; i++){
                                    const J = Math.floor(Math.random() * ROBJ.length);
                                    if(ROBJ != undefined && ROBJ[J].marks==4 && ROBJ[J].question!=undefined){ 
                                        let temp =  " " + ROBJ[J].question  + " "+'<br>' 
                                        if(!tempque.includes(ROBJ[J].question))
                                        {
                                            question2.push( question2.length+1+")  " +temp)
                                            curma += 4
                                            tempque.push(ROBJ[J].question)
                                            console.log( "this is ok ")
                                        }else i--
                                    }else i--
                                }
                            }
                        }
                    }
                    if(question2.length == 4 && question3.length <= 4){
                    var AQ4 = AOBJ.filter(object => object.marks == 4);
                    if (AQ4.length <= 4) {
                        question3.push("not sufficent question in db  <br/> ")
                        question3.push("not sufficent question in db  <br/> ")
                        question3.push("not sufficent question in db  <br/> ")
                        question3.push("not sufficent question in db  <br/> ")
                    }
                    else{
                        var tempque = [] 
                        curma =0 
                        console.log(curma)
                        while (curma < 16){
                            if(curma<16){
                                for(i=1; i <= 1; i++){
                                    const J = Math.floor(Math.random() * AOBJ.length);
                                    if(AOBJ != undefined && AOBJ[J].marks==4 && AOBJ[J].question!=undefined){ 
                                        let temp =  " " + AOBJ[J].question  + " "+'<br>' 
                                        if(!tempque.includes(AOBJ[J].question)){
                                            question3.push( question3.length+1+")  " + temp)
                                            tempque.push(AOBJ[J].question)
                                            curma += 4
                                            //   console.log( "Question three ok" )
                                            //   console.log(curma) 
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                // console.log(question3.length)
                if (question3.length == 4 && question4.length <5 ) {
                    var UQ4 = UOBJ.filter(object => object.marks == 4);
                    if (UQ4.length < 5) {
                        question4.push("not sufficent question in db <br/>")
                        question4.push("not sufficent question in db <br/>")
                        question4.push("not sufficent question in db <br/>")
                        question4.push("not sufficent question in db <br/>")
                        question4.push("not sufficent question in db <br/>")
                        
                    }
                    else {
                        
                        curma =0
                        var tempque = []
                        while (curma < 20){
                            for(i=0; i <= 4; i++){
                                const J = Math.floor(Math.random() * UOBJ.length);
                                if(UOBJ != undefined && UOBJ[J].marks==4 && UOBJ[J].question!=undefined){ 
                                    console.log("Question 4 ok ")
                                    let temp =  " " + UOBJ[J].question  + " " + '<br>' 
                                    // console.log( UOBJ[J].question )
                                    if(!tempque.includes(UOBJ[J].question )){
                                        question4.push(  question4.length+1+")  " + temp)
                                        tempque.push(UOBJ[J].question )
                                        curma =curma + 4 
                                    } else i--
                                }else i--
                            }
                        }
                    }
                }
                if (question4.length==5){
        var queA = AOBJ.filter(object => object.marks == 6);
        var queB = UOBJ.filter(object => object.marks == 6);
        var queR = ROBJ.filter(object => object.marks == 6);
        if (queA.length <= 2){
            question5.push("unsufficient question in db <br/> ")
            question6.push("unsufficient question in db <br/> ")
            
        }
        else if (queB.length <=2){
            question5.push("unsufxficient question in db <br/> ")
            question6.push("unsufficient question in db <br/> ")
            
        }
        else  if (queR.length <= 2){
            question5.push("unsufficient question in db <br/> ")
            question6.push("unsufficient question in db <br/>")
            
        }
        else{  
            curma = 0 
            let r1= 0
            let r2 =0 
            for(i=1; i<=1; i++){  
                //   console.log('here is the problem ') 
                r1= Math.floor(Math.random() * ROBJ.length);
                r2= Math.floor(Math.random() * ROBJ.length);
                if(ROBJ[r1].marks ==6 && ROBJ[r2].marks==6 ){
                    if(ROBJ[r1].question !== ROBJ[r2].question && ROBJ[r1].question!=undefined && ROBJ[r2].question!=undefined) {
                        //   console.log('this is a ', r1,r2 )
                        question5.push( question5.length+1+")  " +  ROBJ[r1].question+  "<br>");
                        question6.push( question6.length+1+")  " + ROBJ[r2].question + "<br>");
                    }else i --
                } else i--
            }
            
            let a1= 0
            let a2 =0    
            for(i=1; i<=1; i++){    
                // console.log('here is the problem ') 
                a1= Math.floor(Math.random() * AOBJ.length);
                a2= Math.floor(Math.random() * AOBJ.length);
                if(AOBJ[a1].question !== AOBJ[a2].question && AOBJ[a2].question!=undefined  && AOBJ[a1].question != undefined) {
                    if(AOBJ[a1].marks ==6 && AOBJ[a2].marks==6 ){
                        //   console.log('this is a ', a1,a2 )
                        question5.push( question5.length+1+")  " +AOBJ[a2].question+ "<br>");
                            question6.push( question6.length+1+")  "+ AOBJ[a1].question + "<br>");
                        }
                        
                        else i--
                    } else i-- 
                    
                }
                let u2 =0
                let u1= 0
                for(i=1; i<=1; i++){
                    
                    u1= Math.floor(Math.random() * UOBJ.length);
                    u2 =Math.floor(Math.random() * UOBJ.length);
                    
                    if([u1] !== [u2]){
                        
                        if(UOBJ[u1].marks ==6 && UOBJ[u2].marks==6 && UOBJ[u1].question!= undefined   && UOBJ[u2].question!=undefined){
                            console.log("passed")
                            console.log('this is u' + u1,u2)
                            question5.push( question5.length+1+")  " +  UOBJ[u1].question+ "<br>");
                            question6.push( question6.length+1+")  " + UOBJ[u2].question+ "<br>");
                            
                        }
                        else i--
                    } else i-- 
                }
            }
        }
        
        
        res.send(` <div class="header" style='display:flex flex-row '>
        <h1 align="right" style="margin-right:2vw">`+ subject + `</h1>
        <div style="display:flex;">
        <h3 align="right" style="margin-right:70vw"> 3 Hours /marks 70 </h3>
        <h3 style="font-weight:bold">  Seat number  - _ _ _ _ _ _ _ </h3> 
        </div>
        <hr>
        <h5>Instructions: </h5>
    (1) All questions are compulsory. <br>
    (2) Illustrate your answers with neat sketches whenever necessary. <br>
    (3) Figure to the right indicate full marks. <br>
    (4) Assume suitable fata if necessary. <br>
    (5) Preferably, write the answers in sequential order. <br>
    <hr>
        </div>
        <main align='left' style="margin-left:4vw">
        <br> <h2 align='left style="margin-left:4vw'>  
        Q1. Attempt any five of the following: (10Marks) </h2> 
        `+ question1.join(' ') +` 
        <h2>Q.2 Attempt any THREE of the following:  (12marks)</h2> <br> `+ 
        question2.join(' ') +`
        <h2>Q.3 Attempt any THREE of the following: (12marks) </h2> <br> `
        + question3.join(' ') + `
        <h2>Q.4 Attempt any THREE of the following: (12marks)</h2> <br> 
        `+ question4.join(' ') +` 
        <h2>Q.5 Attempt any TWO of the following:  (12marks)</h2> <br>` 
        + question5.join(' ') +`
        <h2>Q.6 Attempt any TWO of the following:  (12marks)</h2> <br>`
        + question6.join(' ') 
        +`</main> 
        <input id="printpagebutton" type="button" value="Print Question paper" style=' margin-top: 25px;' onclick="printpage()"/> 
        <button id="newpaper"  style='margin-top:25px;' onclick= "redirect()"> genrate another paper </button>
        <script>
        function printpage() {
            //Get the print button and put it into a variable
            var newpaper = document.getElementById("newpaper");
            var printButton = document.getElementById("printpagebutton");
            //Set the print button visibility to 'hidden' 
            printButton.style.visibility = 'hidden';
            newpaper.style.visibility = 'hidden';

            //Print the page content
            window.print()
        printButton.style.visibility = 'visible';
        newpaper.style.visibility = 'visible';

    }
 function redirect(){
    location.href ="/genrate"
 }
    </script> 
    `
    )}
}
senddat()}
});
});

var context = {};
router.get('/profile', (req, res, next) => {
    User.findOne({ unique_id: req.session.userId }, (err, data) => {
        if (!data) {
            res.redirect('/');
		} else {
        }
	});
    context.count = req.session.count;
    req.session.count = context.count + 1;
console.log(req.session.count)
    return res.render('data.ejs', { "name": data.username, "email": data.email });
});

router.get('/logout', (req, res, next) => {
	if (req.session) {
		// delete session object
		req.session.destroy((err) => {
			if (err) {
				return next(err);
			} else {
				return res.redirect('/');
			}
		});
	}
});

router.get('/forgetpass', (req, res, next) => {
	res.render("forget.ejs");
});

router.post('/forgetpass', (req, res, next) => {
	User.findOne({ email: req.body.email }, (err, data) => {
		if (!data) {
			res.send({ "Success": "This Email Is not regestered!" });
		} else {
            console.log(data)
		}
	});

});

module.exports = router;